class lNode{
	public Customer cp;
	public lNode next;
	public lNode(Customer cn){
		cp=cn;
		next=null;
	}
}
class gq{
	int time_taken;
	int queue_time=0;
	int size=0;
	public lNode head;
	public gq(int time){
		time_taken=time;
	}
	void eq(Customer cn){
		queue_time=max(queue_time-time,0);

		if(head==null){
			head=new lNode(cn);
			return;
		}
		lNode temp=head;
		while(temp.next!=null){
			temp=temp.next;
		}
		lNode x=new lNode(cn);
		temp.next=x;
		queue_time+=time_taken;
		size=ceil(queue_time/time_taken);
	}
	void dq(){
		head=head.next;
		size--;
	}
	public static void main(String[] args) {
        gq ll = new gq(1);
        Customer c1=new Customer(1);
        Customer c2=new Customer(2);
        Customer c3=new Customer(3);
        Customer c4=new Customer(4);
        ll.eq(c1);
        ll.eq(c2);
        ll.eq(c3);
        ll.eq(c4);
        lNode x=ll.head;
        while(x!=null){
        	System.out.println(x.cp.num);
        	x=x.next;
        }
    }
}