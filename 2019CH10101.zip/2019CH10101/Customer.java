class Customer{
	public int numb;
	public int queue_number;
	public int grill_time;
	public int wait_end;
	public int id;
	public Customer(int n1, int gt, int iy){
		id=iy;
		numb=n1;
		grill_time=gt;
		wait_end=Integer.MAX_VALUE;
	}
}