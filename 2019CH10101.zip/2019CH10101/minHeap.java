class minHeap {
    private Customer[] Heap;
    public int size;
    private int maxsize;
    public minHeap(int maxsize)
    {
        this.maxsize = maxsize;
        this.size = 0;
        Heap = new Customer[this.maxsize + 1];
        Heap[0] = new Customer(0,Integer.MIN_VALUE,-1);
    }
    private boolean checkL(int i){
        if (i>(size/2) && i<=size) {
            return true;
        }
        return false;
    }
    private void swap(int i1, int i2){
        Customer t1;
        t1 = Heap[i1];
        Heap[i1] = Heap[i2];
        Heap[i2] = t1;
    }
    private boolean compare(Customer c1, Customer c2){
        if(c1.grill_time>c2.grill_time){
            return true;
        }else if(c1.grill_time<c2.grill_time){
            return false;
        }else{
            if(c1.queue_number<c2.queue_number){
                return true;
            }else{
                return false;
            }
        }
    }
    private void minSort(int i){
        if (!checkL(i)) {
            if (compare(Heap[i],Heap[2*i])||compare(Heap[i],Heap[2*i+1])) {
                if (compare(Heap[2*i+1],Heap[2*i])) {
                    swap(i,2*i);
                    minSort(2*i);
                }
                else {
                    swap(i,2*i+1);
                    minSort(2*i+1);
                }
            }
        }
    }
    public void insert(Customer c1)
    {
 
        if (size >= maxsize) {
            Customer temp[] = new Customer[2*maxsize+1];
            for(int i=0; i<=maxsize; i++){
                temp[i]=Heap[i];
            }
            Heap=temp;
            maxsize=2*maxsize;
        }
        size++;
        Heap[size] = c1;
        int current = size;
 
        while (compare(Heap[current/2],Heap[current])) {
            swap(current, current/2);
            current = current/2;
        }
    }
    public Customer remove()
    {
 
        Customer popped = Heap[1];
        Heap[1] = Heap[size];
        size--;
        minSort(1);

        return popped;
    }
    public Customer mine()
    {
 
        Customer popped = Heap[1];
 
        return popped;
    }
 
    
}