

public class MMBurgers implements MMBurgersInterface{
    public int time=0;
    public int queue_count=0;
    public int grill_count;
    int grill_array[];
    int qt[];
    gq bq[];
    gq grillq = new gq(1);
    int grill_cooked=0;
    int grill_space=0;
    int s1=50;
    minHeap grill_line= new minHeap(50);
    int customer_entry[]= new int[50];
    int customer_grill[]= new int[50];
    int customer_end[]= new int[50];
    int customer_queue[]= new int[50];
    int customer_numb[]= new int[50];
    int latest_id=0;
    public void expandCustomer(int id){
        if(id>=s1){
            int temp1[]=new int[2*s1+1];
            for(int i=0; i<s1; i++){
                temp1[i]=customer_entry[i];
            }
            customer_entry=temp1;
            int temp2[]=new int[2*s1+1];
            for(int i=0; i<s1; i++){
                temp2[i]=customer_grill[i];
            }
            customer_grill=temp2;
            int temp3[]=new int[2*s1+1];
            for(int i=0; i<s1; i++){
                temp3[i]=customer_end[i];
            }
            customer_end=temp3;
            int temp4[]=new int[2*s1+1];
            for(int i=0; i<s1; i++){
                temp4[i]=customer_queue[i];
            }
            customer_queue=temp4;
            int temp0[]=new int[2*s1+1];
            for(int i=0; i<s1; i++){
                temp0[i]=customer_numb[i];
            }
            customer_numb=temp0;
            s1=2*s1+1;
            for(int i=0; i<s1; i++){
                customer_entry[i]=Integer.MAX_VALUE;
                customer_grill[i]=Integer.MAX_VALUE;
                customer_queue[i]=Integer.MAX_VALUE;
            }
        }
    }
    public boolean isEmpty(){
        for(int i=0; i<latest_id; i++){
            if(time<customer_end[i]){
                return false;
            }
        }
        int c1=0;
        for(int i=0; i<grill_count; i++){
            if(grill_array[i]!=0){
                c1++;
            }
        }
        if(grill_line.size==0 && c1==0){
            return true;
        }
        return false;
        //your implementation
	    //throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    } 

    class lNode{
        public Customer cp;
        public lNode next;
        public lNode(Customer cn){
            cp=cn;
            next=null;
        }
    }
    class gq{
        public int time_taken;
        public int queue_time=time;
        gq bq[];
        public lNode head;
        public gq(int time){
            time_taken=time;
        }
        void eq(Customer cn){
            queue_time=time+Math.max(queue_time-time,0);
            if(head==null){
                head=new lNode(cn);
            }else{
                lNode temp=head;
                while(temp.next!=null){
                    temp=temp.next;
                }
                lNode x=new lNode(cn);
                temp.next=x;
            }
            //System.out.println("ID:"+cn.id+" grilltime:"+(queue_time-time));
            queue_time+=time_taken;
            cn.grill_time=queue_time;
            customer_grill[cn.id-1]=cn.grill_time;
            //System.out.println("ID:"+cn.id+" grilltime:"+(queue_time-time));
            //System.out.println("Inside gq:"+size);
        }
        void dq(){
            head=head.next;
        }
    }
    public void setK(int k) throws IllegalNumberException{
        if(k<=0){
            throw new IllegalNumberException();
        }
        qt = new int[k];
        for(int i=0; i<k; i++){
            qt[i]=0;
        }
        for(int i=0; i<s1; i++){
            customer_entry[i]=Integer.MAX_VALUE;
            customer_grill[i]=Integer.MAX_VALUE;
            customer_end[i]=Integer.MAX_VALUE;
        }
        queue_count=k;
        bq=new gq[k];
        for(int i=0; i<k; i++){
            bq[i]=new gq(i+1);
        }
        //your implementation
	    //throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    }   
    
    public void setM(int m) throws IllegalNumberException{
        if(m<=0){
            throw new IllegalNumberException();
        }
        grill_array = new int[m];
        for(int i=0; i<m; i++){
            grill_array[i]=0;
        }
        grill_count=m;
        grill_space=m;

        //your implementation
	    //throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    } 

    public void advanceTime(int t) throws IllegalNumberException{
        if(t<time){
            throw new IllegalNumberException();
        }
        if(t==time){
            return;
        }
        int dt=t-time;
        for(int i=0; i<dt; i++){
            time++;
            for(int j=0; j<grill_count; j++){
                grill_array[j]=Math.max(grill_array[j]-1,0);
                //System.out.println("time="+time+"j="+j+"- "+grill_array[j]+"numb"+grill_line.mine().numb);
                if(grill_array[j]==0 && grill_line.mine().grill_time<=time && grill_line.size>0){
                    grill_line.mine().numb-=1;
                    if(grill_line.mine().numb==0){
                        grill_line.mine().wait_end=time+11;
                        customer_end[grill_line.mine().id-1]=time+11;
                        grill_line.remove();
                    }
                    grill_array[j]=10;
                    grill_cooked++;
                }
            }
        }
        //your implementation
	    //throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    } 

    public void arriveCustomer(int id, int t, int numb) throws IllegalNumberException{
        if(t<time || id<=latest_id){
            throw new IllegalNumberException();
        }
        advanceTime(t);
        latest_id=id;
        if(id>=s1){
            expandCustomer(id);
        }
        customer_entry[id-1]=t;
        customer_numb[id-1]=numb;
        Customer cu = new Customer(numb,Integer.MAX_VALUE,id);
        int min=Integer.MAX_VALUE;
        gq x=bq[0];
        for(int i=0; i<queue_count; i++){
            int s1=(int)Math.ceil((float)Math.max(bq[i].queue_time-time,0)/(float)bq[i].time_taken);
            //System.out.println("i:"+i+"s1: "+s1);
            if(s1<min){
                x=bq[i];
                min=s1;
            }
        }
        x.eq(cu);
        qt[x.time_taken-1]+=x.time_taken;
        //x.queue_time+=x.time_taken;
        cu.queue_number=x.time_taken;
        customer_queue[id-1]=x.time_taken;
        grill_line.insert(cu);
        //System.out.println("Inside arriveCustomer: id"+id+"tt"+x.time_taken);
        
        //your implementation
	    //throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    } 

    public int customerState(int id, int t) throws IllegalNumberException{
        if(t<time){
            throw new IllegalNumberException();
        }
        advanceTime(t);
        if(id>latest_id){
            return 0;
        }
        if(time<customer_grill[id-1]){
            return customer_queue[id-1];
        }
        if(time<customer_end[id-1]){
            return queue_count+1;
        }
        if(time>=customer_end[id-1]){
            return queue_count+2;
        }
        return -1;
        //your implementation
	    //throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    }

    public int griddleState(int t) throws IllegalNumberException{
        if(t<time){
            throw new IllegalNumberException();
        }
        advanceTime(t);
        int c1=0;
        for(int i=0; i<grill_count; i++){
            if(grill_array[i]!=0){
                c1++;
            }
        }
        return c1;
        //your implementation
	    //throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    } 

    public int griddleWait(int t) throws IllegalNumberException{
        if(t<time){
            throw new IllegalNumberException();
        }
        advanceTime(t);
        int g1=0;
        for(int i=0; i<latest_id; i++){
            if(customer_grill[i]<=time){
                g1+=customer_numb[i];
            }
        }
        g1-=grill_cooked;
        return g1;
        //your implementation
	    //throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    } 

    public int customerWaitTime(int id) throws IllegalNumberException{
        if(id>latest_id){
            throw new IllegalNumberException();
        }
        return customer_end[id-1]-customer_entry[id-1];

        //your implementation
	    //throw new java.lang.UnsupportedOperationException("Not implemented yet.");
    }

	public float avgWaitTime(){
        int total=0;
        for(int i=0; i<latest_id; i++){
            total+=customer_end[i]-customer_entry[i];
        }
        float avgt=(float)total/(float)latest_id;
        return avgt;
        //your implementation
	    //throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    } 

    /*public static void main(String[] arguments) throws IllegalNumberException{
        // Small test of the MyStack class
        MMBurgers exmp = new MMBurgers();
        exmp.setK(2);
        exmp.setM(8);
        exmp.arriveCustomer(1,0,5);
        exmp.arriveCustomer(2,0,6);
        exmp.arriveCustomer(3,1,4);
        exmp.arriveCustomer(4,1,5);
        //System.out.println(exmp.bq[0].size);
        exmp.advanceTime(29);
        System.out.println(exmp.customerWaitTime(4));
    }*/
    
}
